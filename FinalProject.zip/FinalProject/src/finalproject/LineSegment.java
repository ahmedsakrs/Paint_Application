package finalproject;

import java.awt.Color;
import java.awt.Point;

public class LineSegment extends GShape 
{
    public LineSegment(Color c, Point p1, Point p2, int s)
    {
        super(c,p1,p2,s);
    }
}
