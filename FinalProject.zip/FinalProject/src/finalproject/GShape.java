/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalproject;

import java.awt.Color;
import java.awt.Point;

/**
 *
 * @author alyth
 */

public class GShape 
{
    private Color shapeColor;
    private int shapeStroke;
    private Point point1, point2;
    
    public GShape(Color c, Point p1, Point p2, int st)
    {
        this.shapeColor = c;
        this.point1 = p1;
        this.point2 = p2;
        this.shapeStroke = st;
    }
    
    void setC(Color c)
    {
        //System.out.println("C CHANGED");
        this.shapeColor = c;
    }
    
    void setPoint1(Point p1)
    {
        this.point1 = p1;
    }
    void setPoint2(Point p2)
    {
        this.point1 = p2;
    }
    
    void setStroke(int s)
    {
        this.shapeStroke = s;
    }
    
    Color getC()
    {
        return this.shapeColor;
    }
    
    Point getPoint1()
    {
        return this.point1;
    }
    
    Point getPoint2()
    {
        return this.point2;
    }
    
    int getStroke()
    {
        return this.shapeStroke;
    }
   
}
