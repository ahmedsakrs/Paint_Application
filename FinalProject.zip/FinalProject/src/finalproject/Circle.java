package finalproject;

import java.awt.Color;
import java.awt.Point;

public class Circle extends GShape {

    public Circle(Color c, Point p1, Point p2, int st) {
        super(c, p1, p2, st);
    }

}