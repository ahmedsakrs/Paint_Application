/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalproject;

import java.awt.Color;
import java.awt.Point;

/**
 *
 * @author LEGION
 */
public class Triangle extends GShape
    {
        Point p3;
        public Triangle(Color color, Point p1, Point p2,Point p3, int stroke){
        super(color, p1, p2, stroke);
        this.p3 = p3;
        
         
    }
    
    
}
