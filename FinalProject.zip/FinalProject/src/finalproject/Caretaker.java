package finalproject;

    public class Caretaker {
    static int top;
    static int MAX = 10000;
    
    static boolean isEmpty()
    {
        return (top < 0);
    }
    Caretaker()
    {
        top = -1;
    }
    
     boolean push(Snapshot x)
    {
         for(int i = 0; i <= top; i ++)
        {
            //System.out.println(PBoard.a.get(i).shapescopy + "  in stack before");
        }
        if (top >= (MAX - 1)) {
            System.out.println("Stack Overflow");
            return false;
        }
        
        else {
            PBoard.a.add(x);
            top++;
            System.out.println(x.shapescopy + " pushed into stack");
        }
        for(int i = 0; i <= top; i ++)
        {
            //System.out.println(PBoard.a.get(i).shapescopy + "  in stack");
            //System.out.println(PBoard.a.get(i).shapescopy + "  in stack");
        }
        return true;
    }
 
     Snapshot pop()
    {
        if (top < 0) {
            Snapshot x = null;
            System.out.println("Stack Underflow");
            return x;
        }
        else {
            Snapshot x = PBoard.a.get(top);
            top--;
            //System.out.println("Will return " + x.shapescopy);
            return x;
        }
    }
}

