/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalproject;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.ArrayList;
import javax.swing.JPanel;

/**
 *
 * @author alyth
 */
public class PBoard extends JPanel implements MouseListener, MouseMotionListener {

    static ArrayList<GShape> shapes = new ArrayList<GShape>();
    ArrayList <Integer> xp = new ArrayList<Integer>();
    ArrayList <Integer> yp = new ArrayList<Integer>();
    static ArrayList <Snapshot> a = new ArrayList <Snapshot>();
    Caretaker c = new Caretaker();
    public static int currentShape;
    public int trianglep = 0;
    public int id = 0;
    public static Color currentColor = new Color(0, 0, 0);
    public PBoard() {
        addMouseListener(this);
        addMouseMotionListener(this);
        makeSnapshot();
    }

    static void setColor(Color c) {
        currentColor = c;
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        
        for (GShape shape : shapes) {
            if (shape instanceof LineSegment) {
                g.setColor(shape.getC());
                g.drawLine(shape.getPoint1().x, shape.getPoint1().y, shape.getPoint2().x, shape.getPoint2().y);
            } else if (shape instanceof Rectangle) {
                g.setColor(shape.getC());
                g.drawRect(Math.min(shape.getPoint1().x, shape.getPoint2().x), Math.min(shape.getPoint1().y, shape.getPoint2().y), Math.abs(shape.getPoint1().x - shape.getPoint2().x), Math.abs(shape.getPoint1().y - shape.getPoint2().y));
            } else if (shape instanceof Square) {
                g.setColor(shape.getC());
                g.drawRect(Math.min(shape.getPoint1().x, shape.getPoint2().x), Math.min(shape.getPoint1().y, shape.getPoint2().y), Math.abs(shape.getPoint1().x - shape.getPoint2().x), Math.abs(shape.getPoint1().x - shape.getPoint2().x));
            } else if (shape instanceof Circle) {
                g.setColor(shape.getC());
                g.drawOval(Math.min(shape.getPoint1().x, shape.getPoint2().x), Math.min(shape.getPoint1().y, shape.getPoint2().y), Math.abs(shape.getPoint1().x - shape.getPoint2().x), Math.abs(shape.getPoint1().x - shape.getPoint2().x));
            }else if (shape instanceof Triangle) {
                    g.setColor(shape.getC());
                    int xpoints[] = {shape.getPoint1().x, shape.getPoint2().x, ((Triangle) shape).p3.x};
                    int ypoints[] = {shape.getPoint1().y, shape.getPoint2().y, ((Triangle) shape).p3.y};
                    int npoints = 3;
                    g.drawPolygon(xpoints, ypoints, npoints);
            }
        }
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        if(currentShape == 4)
        {
            
        }
    }

    @Override
    public void mousePressed(MouseEvent e) {
        Point p1 = new Point(e.getX(), e.getY());
        switch (currentShape) 
        {
            
            case 0:
                LineSegment lineSegment = new LineSegment(currentColor, p1, p1, 2);
                shapes.add(lineSegment);
                break;
                
            case 1:
                Rectangle rectangle = new Rectangle(currentColor, p1, p1, 2);
                shapes.add(rectangle);
                break;
                
            case 2:
                Square square = new Square(currentColor, p1, p1, 2);
                shapes.add(square);
                break;
                
            case 3:
                Circle circle = new Circle(currentColor, p1, p1, 23);
                shapes.add(circle);
                break;
            case 4:
                xp.add(e.getX());
                yp.add(e.getY());
                trianglep++;
            if(trianglep == 3)
            {
                Triangle triangle = new Triangle(currentColor, new Point(xp.get(0).intValue(),yp.get(0).intValue()),new Point(xp.get(1).intValue(),yp.get(1).intValue()),new Point(xp.get(2).intValue(),yp.get(2).intValue()),2);
                shapes.add(triangle);
                            makeSnapshot();
                repaint();
                trianglep = 0;
                xp.clear();
                yp.clear();
            }
                
                break;
        }
        makeSnapshot();
        repaint();

    }

    @Override
    public void mouseReleased(MouseEvent e
    ) {
    }

    @Override
    public void mouseEntered(MouseEvent e
    ) {
    }

    @Override
    public void mouseExited(MouseEvent e
    ) {
    }

    @Override
    public void mouseDragged(MouseEvent e
    ) {
        
        Point p2 = new Point(e.getX(), e.getY());
        GShape shape = shapes.get(shapes.size() - 1);
        if (currentShape >= 0 && currentShape < 7) {
            switch (currentShape) {
                case 0:
                    LineSegment lineSegment = (LineSegment) shape;
                    lineSegment.setPoint2(p2);
                    break;
                case 1:
                    Rectangle rectangle = (Rectangle) shape;
                    rectangle.setPoint2(p2);
                    break;
                case 2:
                    Square square = (Square) shape;
                    square.setPoint2(p2);
                    break;
                case 3:
                    Circle circle = (Circle) shape;
                    circle.setPoint2(p2);
                    break;
                case 4:
                    
                    break;
            }
        }
        repaint();

    }

    @Override
    public void mouseMoved(MouseEvent e
    ) {
    }
    void makeSnapshot()
    {
        System.out.println("Making snapshot");
        c.push(new Snapshot(shapes));
        System.out.println(a.get(0).shapescopy);
    }
    public void restorelastSnapshot()
    {
        Snapshot temp = c.pop();
        System.out.println(temp.shapescopy.get(0).getPoint1());
        this.shapes = temp.shapescopy;
        repaint();
    }
}
